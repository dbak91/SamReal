/* Functions as an appender to the htmls to append functionJ main script but with a unique name each fetch to hack no caching (else caching causing eleemnts to dispay wrong widths if first come from a different page 
	
	*/

function applyAdjustments(){
	
	document.addEventListener('DOMContentLoaded',function()
	{  
		const script1 = document.createElement('script');
		script1.src = `js/insertMenuFunction.js?v=${new Date().getTime()}`; //generrate unique timestamp name as v stop caching so sharted widths readjust
		document.body.appendChild(script1);
	});

}

window.addEventListener('load', applyAdjustments);
	
applyAdjustments();
		